# IntelliDoc

NLP-based intelligent document understanding and semantic question answering.
Upload a PDF, Word or text file. IntelliDoc extracts the text, cleans it, finds keywords and
named entities, classifies the document, writes a summary, and lets you search and ask
questions by meaning.

```
frontend/   React (Vite) - Workspace, Upload, Search, Ask, Library
backend/    FastAPI + NLP pipeline
samples/    A sample research paper to try the app
```

## How it works

| Step | What happens | Tool |
|---|---|---|
| 1. Extract | Read text from PDF / DOCX / TXT, repair broken lines | pypdf, python-docx |
| 2. Preprocess | Sentence split, tokenize, stop-word removal, lemmatization, passage chunking | NLTK |
| 3. Analyse | Keywords (TF-IDF, noun filter) and named entities (people, organizations, places, dates) | scikit-learn, spaCy |
| 4. Embed | Every passage becomes a vector that captures its meaning | Sentence-Transformers (all-MiniLM-L6-v2) |
| 5. Index | Classification, summaries, vector index | FAISS (or NumPy), scikit-learn |

- **Classification**: the document vector is compared with a plain-language description of each
  category (research paper, technical document, business report, legal, news, educational), then
  adjusted by structural cues such as "abstract" or "references".
- **Summary**: extractive. Sentences are ranked with TextRank plus closeness to the document
  centre, so every summary line is copied from the document.
- **Semantic search**: the query is embedded and compared with all passages (cosine similarity).
- **Question answering**: the best passages are retrieved, then an extractive QA model
  (deepset/roberta-base-squad2) finds the answer span. If the document does not answer the
  question, IntelliDoc says so instead of guessing.

## Run it

You need Python 3.10+ and Node 18+.

### 1. Backend

```bash
cd backend
python -m venv .venv
.venv\Scripts\activate            # Windows      (Mac/Linux: source .venv/bin/activate)
pip install -r requirements.txt
python setup_nlp.py               # one-time download of NLP models (about 600 MB)
uvicorn app.main:app --reload
```

API docs: http://localhost:8000/docs

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173

### Single-server mode (for the demo)

```bash
cd frontend && npm run build
cd ../backend && uvicorn app.main:app
```

Open http://localhost:8000 - FastAPI serves the built React app.

## Configuration (environment variables)

| Variable | Default | Meaning |
|---|---|---|
| `MONGODB_URI` | empty | Store document data in MongoDB. Empty = local JSON files in `backend/data/` |
| `INTELLIDOC_LIGHT` | `0` | `1` skips the heavy models and uses word matching (fast, no downloads) |
| `EMBEDDING_MODEL` | `all-MiniLM-L6-v2` | Any Sentence-Transformers model |
| `QA_MODEL` | `deepset/roberta-base-squad2` | Any extractive QA model |
| `SPACY_MODEL` | `en_core_web_sm` | Use `en_core_web_md` or `_lg` for better entity detection |
| `MAX_UPLOAD_MB` | `50` | Upload size limit |

`GET /api/health` shows which engines are active. If the embedding model is not available the
app still works in word-matching mode and the Search and Ask pages tell you so.

## Tests

```bash
cd backend
python -m pytest
```

The tests cover upload validation, PDF / DOCX / TXT extraction, the full pipeline, search,
question answering, unanswerable questions and deletion. They run in light mode, so they need no
model downloads.

## Known limitations

- Scanned PDFs (images of text) are rejected with a clear message. OCR is not included.
- Entity detection uses a small spaCy model. It can miss or mislabel names in technical text.
- Summaries are extractive; they pick sentences and do not rewrite them.
- Question answering returns spans from the text. It does not do multi-step reasoning across sections.
- English only.

## API

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/documents` | Upload a file (returns immediately, processing runs in the background) |
| GET | `/api/documents` | List documents |
| GET | `/api/documents/{id}` | Full analysis and processing progress |
| DELETE | `/api/documents/{id}` | Remove a document |
| POST | `/api/search` | `{query, document_id?}` semantic search |
| POST | `/api/ask` | `{question, document_id?}` question answering |
| GET | `/api/health` | Active engines and storage |
