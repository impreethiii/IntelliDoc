import { Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar.jsx";
import Footer from "./components/Footer.jsx";
import Workspace from "./pages/Workspace.jsx";
import Upload from "./pages/Upload.jsx";
import Search from "./pages/Search.jsx";
import Ask from "./pages/Ask.jsx";
import Library from "./pages/Library.jsx";

export default function App() {
  return (
    <div className="app">
      <Navbar />
      <main className="main">
        <Routes>
          <Route path="/" element={<Workspace />} />
          <Route path="/upload" element={<Upload />} />
          <Route path="/search" element={<Search />} />
          <Route path="/ask" element={<Ask />} />
          <Route path="/library" element={<Library />} />
          <Route path="*" element={<Workspace />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}
