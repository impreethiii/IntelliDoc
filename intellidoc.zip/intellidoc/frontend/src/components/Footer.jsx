export default function Footer() {
  return (
    <footer className="footer">
      IntelliDoc | NLP-Based Document Understanding | Coimbatore Institute of Technology
    </footer>
  );
}
