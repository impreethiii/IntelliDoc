import { FileText, Upload } from "lucide-react";
import { Link, NavLink, useSearchParams } from "react-router-dom";

const TABS = [
  { to: "/", label: "Workspace", end: true },
  { to: "/search", label: "Search" },
  { to: "/ask", label: "Ask" },
  { to: "/library", label: "Library" },
];

export default function Navbar() {
  const [params] = useSearchParams();
  const doc = params.get("doc");
  // keep the chosen document when moving between Workspace and Ask
  const withDoc = (to) => (doc && ["/", "/ask"].includes(to) ? `${to}?doc=${doc}` : to);

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="brand" aria-label="IntelliDoc home">
          <span className="brand-mark"><FileText size={18} strokeWidth={2} /></span>
          <span className="brand-name">IntelliDoc</span>
        </Link>
        <nav className="tabs" aria-label="Main">
          {TABS.map((t) => (
            <NavLink key={t.to} to={withDoc(t.to)} end={t.end} className={({ isActive }) => `tab${isActive ? " active" : ""}`}>
              {t.label}
            </NavLink>
          ))}
        </nav>
        <Link to="/upload" className="nav-upload">
          <Upload size={16} /> Upload document
        </Link>
      </div>
    </header>
  );
}
