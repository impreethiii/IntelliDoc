import { AlertCircle, FileText } from "lucide-react";
import { Link } from "react-router-dom";

export function Notice({ children, tone = "error" }) {
  return (
    <div className={`notice ${tone}`} role={tone === "error" ? "alert" : "status"}>
      <AlertCircle size={18} />
      <span>{children}</span>
    </div>
  );
}

export function EmptyState({ title, text, actionLabel = "Upload a document", to = "/upload" }) {
  return (
    <div className="empty">
      <FileText size={32} strokeWidth={1.5} />
      <h2>{title}</h2>
      <p>{text}</p>
      {actionLabel && <Link to={to} className="btn primary">{actionLabel}</Link>}
    </div>
  );
}

export function Loading({ label = "Loading" }) {
  return <p className="muted loading" role="status">{label}...</p>;
}

export function Meter({ value, tone = "blue", label }) {
  const pct = Math.max(0, Math.min(1, value || 0));
  return (
    <span className="meter-wrap" title={label}>
      <span className={`meter ${tone}`} aria-hidden="true">
        <span style={{ width: `${pct * 100}%` }} />
      </span>
    </span>
  );
}

export function DocSelect({ docs, value, onChange, allowAll = false, id = "doc-select" }) {
  return (
    <select id={id} className="select" value={value || ""} onChange={(e) => onChange(e.target.value || null)} aria-label="Document">
      {allowAll && <option value="">All documents</option>}
      {docs.map((d) => (
        <option key={d.id} value={d.id}>{d.title}</option>
      ))}
    </select>
  );
}
