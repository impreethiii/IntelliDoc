// Thin wrapper around the FastAPI backend.
const BASE = import.meta.env.VITE_API_URL || "";

export class ApiError extends Error {}

async function request(path, options = {}) {
  let res;
  try {
    res = await fetch(`${BASE}${path}`, options);
  } catch {
    throw new ApiError(
      "Can't reach the IntelliDoc server. Start the backend (uvicorn app.main:app) and try again."
    );
  }
  if (res.status === 204) return null;
  let body = null;
  try {
    body = await res.json();
  } catch {
    /* non-JSON response */
  }
  if (!res.ok) {
    const detail = body?.detail;
    const message = typeof detail === "string" ? detail : detail?.[0]?.msg || `Request failed (${res.status})`;
    throw new ApiError(message);
  }
  return body;
}

const json = (data) => ({
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(data),
});

export const api = {
  health: () => request("/api/health"),
  listDocuments: () => request("/api/documents"),
  getDocument: (id) => request(`/api/documents/${id}`),
  deleteDocument: (id) => request(`/api/documents/${id}`, { method: "DELETE" }),
  uploadDocument: (file) => {
    const form = new FormData();
    form.append("file", file);
    return request("/api/documents", { method: "POST", body: form });
  },
  search: (query, documentId) => request("/api/search", json({ query, document_id: documentId || null, top_k: 5 })),
  ask: (question, documentId) => request("/api/ask", json({ question, document_id: documentId || null })),
};
