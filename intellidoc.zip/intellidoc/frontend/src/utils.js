import { useCallback, useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { api } from "./api";

export const formatDate = (iso) =>
  iso ? new Date(iso).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }) : "";

export const formatSize = (bytes) => {
  if (!bytes && bytes !== 0) return "";
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

export const percent = (value) => `${Math.round((value || 0) * 100)}%`;

export const plural = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;

const LAST_DOC_KEY = "intellidoc:lastDoc";

/** All documents, loaded once and re-loadable. */
export function useDocuments() {
  const [docs, setDocs] = useState(null);
  const [error, setError] = useState("");

  const reload = useCallback(async () => {
    try {
      setDocs(await api.listDocuments());
      setError("");
    } catch (e) {
      setError(e.message);
      setDocs([]);
    }
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  return { docs, error, reload };
}

/** Which document the user is looking at: ?doc=<id>, else the last one opened, else the newest. */
export function useSelectedDocId(docs) {
  const [params, setParams] = useSearchParams();
  const fromUrl = params.get("doc");
  const ready = (docs || []).filter((d) => d.status === "ready");

  let id = null;
  if (fromUrl && ready.some((d) => d.id === fromUrl)) id = fromUrl;
  else if (ready.length) {
    const remembered = localStorage.getItem(LAST_DOC_KEY);
    id = ready.some((d) => d.id === remembered) ? remembered : ready[0].id;
  }

  useEffect(() => {
    if (id) localStorage.setItem(LAST_DOC_KEY, id);
  }, [id]);

  const select = (next) => setParams(next ? { doc: next } : {}, { replace: true });
  return [id, select, ready];
}
