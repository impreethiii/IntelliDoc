import { Copy, Check, MessageSquare } from "lucide-react";
import { Fragment, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import { DocSelect, EmptyState, Loading, Notice } from "../components/Common.jsx";
import { formatSize, percent, plural, useDocuments, useSelectedDocId } from "../utils";

const GROUPS = ["Person", "Organization", "Location", "Date"];
const TABS = ["Summary", "Keywords", "Entities", "Preprocessing"];

const escapeRegExp = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** Wrap known entities inside a paragraph with coloured <mark>s. */
function Highlighted({ text, entities }) {
  const lookup = useMemo(() => {
    const map = new Map();
    GROUPS.forEach((g) => (entities?.[g] || []).forEach((e) => map.set(e.text.toLowerCase(), g)));
    return map;
  }, [entities]);

  const pattern = useMemo(() => {
    const terms = [...lookup.keys()].sort((a, b) => b.length - a.length).map(escapeRegExp);
    return terms.length ? new RegExp(`(?<![\\w])(${terms.join("|")})(?![\\w])`, "gi") : null;
  }, [lookup]);

  if (!pattern) return text;
  return text.split(pattern).map((part, i) => {
    const group = lookup.get(part.toLowerCase());
    return group && i % 2 === 1 ? (
      <mark key={i} className={`ent ent-${group}`}>{part}</mark>
    ) : (
      <Fragment key={i}>{part}</Fragment>
    );
  });
}

function SummaryTab({ doc }) {
  const [mode, setMode] = useState("short");
  const [copied, setCopied] = useState(false);
  const text = doc.summary?.[mode] || "";

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard blocked - ignore */
    }
  };

  return (
    <>
      <div className="analysis-body">
        <div style={{ display: "flex", justifyContent: "flex-end" }}>
          <div className="toggle" role="group" aria-label="Summary length">
            <button className={mode === "short" ? "on" : ""} onClick={() => setMode("short")}>Short</button>
            <button className={mode === "detailed" ? "on" : ""} onClick={() => setMode("detailed")}>Detailed</button>
          </div>
        </div>
        <p className="summary-text">{text}</p>
        <p className="muted small hint" style={{ marginTop: 12 }}>
          Built from the most central sentences of the document, so every line comes straight from the source.
        </p>
      </div>
      <div className="analysis-foot">
        <button className="btn ghost" onClick={copy}>
          {copied ? <Check size={16} /> : <Copy size={16} />} {copied ? "Copied" : "Copy summary"}
        </button>
        <Link className="btn primary" to={`/ask?doc=${doc.id}`}>
          <MessageSquare size={16} /> Ask a question
        </Link>
      </div>
    </>
  );
}

function KeywordsTab({ doc }) {
  const items = doc.keywords || [];
  if (!items.length) return <p className="muted">No keywords were found.</p>;
  return (
    <div className="analysis-body">
      <p className="muted small hint">Ranked by TF-IDF. Larger terms matter more to this document.</p>
      <div className="chips">
        {items.map((k) => (
          <span key={k.term} className="chip" style={{ fontSize: `${14 + Math.round(k.score * 6)}px` }}>
            {k.term}
          </span>
        ))}
      </div>
    </div>
  );
}

function EntitiesTab({ doc }) {
  return (
    <div className="analysis-body">
      <div className="entity-groups">
        {GROUPS.map((g) => {
          const list = doc.entities?.[g] || [];
          return (
            <section key={g} className="entity-group">
              <h3>{g === "Person" ? "People" : g === "Organization" ? "Organizations" : g === "Location" ? "Locations" : "Dates"}<span className="muted">{list.length}</span></h3>
              {list.length ? (
                <ul>
                  {list.map((e) => (
                    <li key={e.text}><span>{e.text}</span><span>{e.count > 1 ? `${e.count} mentions` : "1 mention"}</span></li>
                  ))}
                </ul>
              ) : (
                <p className="muted small">None found.</p>
              )}
            </section>
          );
        })}
      </div>
      <p className="muted small" style={{ marginTop: 28 }}>
        Detected with {doc.engine?.ner}. Small models can miss or mislabel names in technical text.
      </p>
    </div>
  );
}

function PreprocessingTab({ doc }) {
  const p = doc.preprocessing;
  if (!p) return null;
  const join = (arr) => arr.join(" · ");
  return (
    <div className="analysis-body">
      <div className="stats">
        <div className="stat"><b>{p.stats.sentences}</b><span>sentences</span></div>
        <div className="stat"><b>{p.stats.tokens}</b><span>tokens</span></div>
        <div className="stat"><b>{p.stats.after_stopwords}</b><span>after stop-word removal</span></div>
        <div className="stat"><b>{p.stats.unique_lemmas}</b><span>unique lemmas</span></div>
      </div>
      <div className="steps">
        <div className="step-block"><h3>Original text</h3><p>{p.original}</p></div>
        <div className="step-block"><h3>After tokenization</h3><p>{join(p.tokens)}</p></div>
        <div className="step-block"><h3>After stop-word removal</h3><p>{join(p.no_stopwords)}</p></div>
        <div className="step-block"><h3>After lemmatization</h3><p>{join(p.lemmas)}</p></div>
      </div>
    </div>
  );
}

export default function Workspace() {
  const { docs, error: listError } = useDocuments();
  const [docId, selectDoc, ready] = useSelectedDocId(docs);
  const [doc, setDoc] = useState(null);
  const [error, setError] = useState("");
  const [tab, setTab] = useState("Summary");

  useEffect(() => {
    if (!docId) return;
    let cancelled = false;
    setDoc(null);
    api.getDocument(docId).then((d) => !cancelled && setDoc(d)).catch((e) => !cancelled && setError(e.message));
    return () => { cancelled = true; };
  }, [docId]);

  if (docs === null) return <Loading />;
  if (listError) return <Notice>{listError}</Notice>;
  if (!ready.length) {
    return (
      <EmptyState
        title="No documents yet"
        text="Upload a PDF, Word or text file and IntelliDoc will summarise it, find the key terms and let you ask questions."
      />
    );
  }
  if (error) return <Notice>{error}</Notice>;
  if (!doc) return <Loading label="Opening document" />;

  const isHeading = (p) => p.split(/\s+/).length <= 8 && !/[.!?:;]$/.test(p.trim());
  const paragraphs = (doc.preview || "")
    .split("\n\n")
    .filter(Boolean)
    .filter((p, i) => !(i === 0 && p.trim() === doc.title.trim()));       // title is already shown above
  const truncated = (doc.preview || "").split(/\s+/).length < (doc.word_count || 0) * 0.98;

  return (
    <>
      {ready.length > 1 && (
        <div style={{ marginBottom: 24, display: "flex", justifyContent: "flex-end" }}>
          <DocSelect docs={ready} value={docId} onChange={selectDoc} />
        </div>
      )}
      <div className="workspace">
        <section className="card reader" aria-label="Document text">
          <span className="badge amber">{doc.category.label} &bull; {percent(doc.category.confidence)} confidence</span>
          <h1>{doc.title}</h1>
          <div className="file-meta">
            {doc.file_type} &bull; {plural(doc.pages, "page")} &bull; {plural(doc.word_count, "word")} &bull; {formatSize(doc.size_bytes)}
          </div>
          <div className="reader-body">
            {paragraphs.map((p, i) =>
              isHeading(p) ? <h3 key={i} className="doc-heading">{p}</h3> : <p key={i}><Highlighted text={p} entities={doc.entities} /></p>
            )}
          </div>
          {truncated && <p className="muted small reader-note">Showing the opening of the document.</p>}
          <div className="legend" aria-label="Highlight colours">
            <strong style={{ fontWeight: 500, color: "var(--navy)" }}>Highlighted</strong>
            <span><i className="swatch" style={{ background: "#dbe6ff" }} />People</span>
            <span><i className="swatch" style={{ background: "#cbd5e1" }} />Organizations</span>
            <span><i className="swatch" style={{ background: "#bbf7d0" }} />Locations</span>
            <span><i className="swatch" style={{ background: "#a5f3fc" }} />Dates</span>
          </div>
        </section>

        <section className="card analysis" aria-label="Analysis">
          <div className="analysis-head">
            <div className="analysis-tabs" role="tablist">
              {TABS.map((t) => (
                <button key={t} role="tab" aria-selected={tab === t} className={`atab${tab === t ? " active" : ""}`} onClick={() => setTab(t)}>
                  {t}
                </button>
              ))}
            </div>
          </div>
          {tab === "Summary" && <SummaryTab doc={doc} />}
          {tab === "Keywords" && <KeywordsTab doc={doc} />}
          {tab === "Entities" && <EntitiesTab doc={doc} />}
          {tab === "Preprocessing" && <PreprocessingTab doc={doc} />}
        </section>
      </div>
    </>
  );
}
