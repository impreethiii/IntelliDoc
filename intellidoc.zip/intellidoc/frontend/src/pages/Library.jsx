import { Plus, Search as SearchIcon, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import { EmptyState, Loading, Notice } from "../components/Common.jsx";
import { formatDate, plural, useDocuments } from "../utils";

function Status({ doc }) {
  if (doc.status === "processing") return <span className="badge neutral">Processing {doc.progress}%</span>;
  if (doc.status === "failed") return <span className="badge danger" title={doc.error}>Failed</span>;
  return <span className="badge">{doc.category?.label}</span>;
}

export default function Library() {
  const { docs, error, reload } = useDocuments();
  const [filter, setFilter] = useState("");
  const [confirming, setConfirming] = useState(null);
  const [actionError, setActionError] = useState("");

  const shown = useMemo(() => {
    const f = filter.trim().toLowerCase();
    return (docs || []).filter((d) => !f || d.title?.toLowerCase().includes(f) || d.filename?.toLowerCase().includes(f) || d.category?.label?.toLowerCase().includes(f));
  }, [docs, filter]);

  const remove = async (id) => {
    try {
      await api.deleteDocument(id);
      setConfirming(null);
      if (localStorage.getItem("intellidoc:lastDoc") === id) localStorage.removeItem("intellidoc:lastDoc");
      reload();
    } catch (e) {
      setActionError(e.message);
    }
  };

  if (docs === null) return <Loading />;

  return (
    <div>
      <div className="lib-head">
        <h1>Library</h1>
        <p>All uploaded documents</p>
      </div>

      {(error || actionError) && <Notice>{error || actionError}</Notice>}

      {docs.length === 0 && !error ? (
        <EmptyState title="Your library is empty" text="Documents you upload will appear here." />
      ) : (
        <>
          <div className="lib-tools">
            <div className="searchbar">
              <SearchIcon size={18} />
              <input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Filter by title or category" aria-label="Filter documents" />
            </div>
          </div>

          <div className="card table-wrap">
            <table>
              <colgroup><col className="col-name" /><col className="col-cat" /><col className="col-date" /><col className="col-act" /></colgroup>
              <thead>
                <tr><th>Name</th><th>Category</th><th>Date</th><th aria-label="Actions" /></tr>
              </thead>
              <tbody>
                {shown.map((d) => (
                  <tr key={d.id}>
                    <td className="name">
                      {d.status === "ready" ? (
                        <Link to={`/?doc=${d.id}`}><b>{d.title}</b></Link>
                      ) : (
                        <b>{d.title}</b>
                      )}
                      <span>{d.file_type}{d.pages ? ` • ${plural(d.pages, "page")}` : ""}</span>
                    </td>
                    <td><Status doc={d} /></td>
                    <td>{formatDate(d.uploaded_at)}</td>
                    <td className="actions">
                      {confirming === d.id ? (
                        <span className="confirm">
                          Delete?
                          <button className="btn ghost" style={{ color: "var(--danger)" }} onClick={() => remove(d.id)}>Yes</button>
                          <button className="btn ghost" onClick={() => setConfirming(null)}>No</button>
                        </span>
                      ) : (
                        <>
                          {d.status === "ready" && <Link to={`/?doc=${d.id}`} style={{ marginRight: 8 }}>Open</Link>}
                          <button className="icon-btn" onClick={() => setConfirming(d.id)} aria-label={`Delete ${d.title}`}><Trash2 size={17} /></button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!shown.length && <p className="muted" style={{ padding: 24, textAlign: "center", margin: 0 }}>No documents match &ldquo;{filter}&rdquo;.</p>}
          </div>

          <div className="lib-foot">
            <span>Showing {shown.length} of {docs.length}</span>
            <Link className="btn primary" to="/upload"><Plus size={16} /> Upload new document</Link>
          </div>
        </>
      )}
    </div>
  );
}
