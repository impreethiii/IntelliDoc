import { Check, FileText, Loader2, UploadCloud, X } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import { Notice } from "../components/Common.jsx";
import { formatSize } from "../utils";

const STEPS = ["Extract", "Preprocess", "Analyse", "Embed", "Index"];
const ACCEPT = ".pdf,.docx,.txt";

function Stepper({ upload }) {
  return (
    <div className="card stepper" aria-label="Processing steps">
      {STEPS.map((name, i) => {
        let state = "pending";
        if (upload.status === "ready" || i < upload.stage) state = "done";
        else if (upload.status === "failed" && i === Math.min(upload.stage, STEPS.length - 1)) state = "failed";
        else if (i === upload.stage) state = "active";
        const caption = { done: "Done", active: "Working", failed: "Stopped", pending: "Waiting" }[state];
        return (
          <div key={name} className={`pstep ${state}`}>
            <span className="dot">
              {state === "done" ? <Check size={16} /> : state === "active" ? <Loader2 size={16} className="spin" /> : state === "failed" ? <X size={16} /> : i + 1}
            </span>
            <b>{name}</b>
            <small>{caption}</small>
          </div>
        );
      })}
    </div>
  );
}

export default function Upload() {
  const [uploads, setUploads] = useState([]);       // newest first
  const [error, setError] = useState("");
  const [over, setOver] = useState(false);
  const input = useRef(null);

  const patch = useCallback((id, fields) => {
    setUploads((list) => list.map((u) => (u.id === id ? { ...u, ...fields } : u)));
  }, []);

  const startUpload = useCallback(async (file) => {
    setError("");
    const ext = file.name.slice(file.name.lastIndexOf(".")).toLowerCase();
    if (![".pdf", ".docx", ".txt"].includes(ext)) {
      setError(`"${file.name}" is not supported. Please choose a PDF, DOCX or TXT file.`);
      return;
    }
    try {
      const doc = await api.uploadDocument(file);
      setUploads((list) => [{ id: doc.id, name: file.name, size: file.size, status: "processing", stage: 0, progress: 0, detail: "Waiting to start" }, ...list]);
    } catch (e) {
      setError(e.message);
    }
  }, []);

  const onFiles = (files) => Array.from(files || []).forEach(startUpload);

  // poll anything still processing
  useEffect(() => {
    const active = uploads.filter((u) => u.status === "processing");
    if (!active.length) return;
    const timer = setInterval(async () => {
      for (const u of active) {
        try {
          const d = await api.getDocument(u.id);
          patch(u.id, { status: d.status, stage: d.stage ?? 0, progress: d.progress ?? 0, detail: d.stage_detail, error: d.error, title: d.title });
        } catch (e) {
          patch(u.id, { status: "failed", error: e.message });
        }
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [uploads, patch]);

  const current = uploads[0];

  return (
    <div className="narrow">
      <div className="page-head">
        <h1>Upload a document</h1>
        <p>PDF, DOCX or TXT files up to 50 MB</p>
      </div>

      {error && <Notice>{error}</Notice>}

      <div
        className={`card dropzone${over ? " over" : ""}`}
        onDragOver={(e) => { e.preventDefault(); setOver(true); }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); onFiles(e.dataTransfer.files); }}
      >
        <div className="drop-icon"><UploadCloud size={26} /></div>
        <p>Drag and drop your document here, or</p>
        <button className="btn primary" onClick={() => input.current?.click()}>Browse files</button>
        <input ref={input} type="file" accept={ACCEPT} multiple hidden onChange={(e) => { onFiles(e.target.files); e.target.value = ""; }} />
      </div>

      {current && (
        <>
          <div className="section-label">Processing status</div>
          <Stepper upload={current} />

          <div className="files">
            {uploads.map((u) => (
              <div key={u.id} className="card file-card">
                <div className="file-row">
                  <div className="file-icon"><FileText size={22} /></div>
                  <div className="file-info">
                    <b>{u.title || u.name}</b>
                    <span className="muted small">
                      {formatSize(u.size)} &bull; {u.status === "ready" ? "Ready" : u.status === "failed" ? "Could not process" : u.detail}
                    </span>
                  </div>
                  {u.status === "ready" ? (
                    <Link className="btn primary" to={`/?doc=${u.id}`}>Open in workspace</Link>
                  ) : u.status === "processing" ? (
                    <span className="file-pct">{u.progress}%</span>
                  ) : null}
                </div>
                <div className={`bar${u.status === "failed" ? " failed" : ""}`}>
                  <span style={{ width: `${u.status === "failed" ? 100 : u.status === "ready" ? 100 : u.progress}%` }} />
                </div>
                {u.status === "failed" && <p className="file-error">{u.error}</p>}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
