import { Search as SearchIcon } from "lucide-react";
import { Fragment, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import { DocSelect, EmptyState, Loading, Meter, Notice } from "../components/Common.jsx";
import { percent, useDocuments } from "../utils";

/** Show a passage with its best-matching sentence highlighted. */
function Passage({ text, highlight }) {
  const at = highlight ? text.indexOf(highlight) : -1;
  if (at === -1) return <mark>{text}</mark>;
  return (
    <Fragment>
      {at > 0 && <span className="result-ctx">&hellip; {text.slice(0, at)}</span>}
      <mark>{highlight}</mark>
      {at + highlight.length < text.length && <span className="result-ctx"> {text.slice(at + highlight.length)} &hellip;</span>}
    </Fragment>
  );
}

export default function Search() {
  const { docs, error: listError } = useDocuments();
  const [query, setQuery] = useState("");
  const [docId, setDocId] = useState(null);
  const [state, setState] = useState({ status: "idle", results: [], semantic: true, asked: "" });
  const [error, setError] = useState("");

  const ready = (docs || []).filter((d) => d.status === "ready");

  const run = async (e) => {
    e.preventDefault();
    const q = query.trim();
    if (q.length < 2) return;
    setError("");
    setState((s) => ({ ...s, status: "loading" }));
    try {
      const res = await api.search(q, docId);
      setState({ status: "done", results: res.results, semantic: res.semantic, asked: q });
    } catch (err) {
      setError(err.message);
      setState((s) => ({ ...s, status: "idle" }));
    }
  };

  if (docs === null) return <Loading />;
  if (listError) return <Notice>{listError}</Notice>;
  if (!ready.length) {
    return <EmptyState title="Nothing to search yet" text="Upload a document first, then search it by describing what you are looking for." />;
  }

  return (
    <div className="narrow">
      <div className="page-head">
        <h1>Search by meaning</h1>
        <p>Describe what you are looking for in your own words.</p>
      </div>

      {error && <Notice>{error}</Notice>}

      <form onSubmit={run} role="search">
        <div className="searchbar">
          <SearchIcon size={20} />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Which loss function handles class imbalance?"
            aria-label="Search query"
          />
          <button className="btn primary" type="submit" disabled={state.status === "loading" || query.trim().length < 2}>Search</button>
        </div>
      </form>

      <div className="search-meta">
        <DocSelect docs={ready} value={docId} onChange={setDocId} allowAll />
        {state.status === "done" && (
          <span className="muted small">
            {state.results.length ? `Showing ${state.results.length} ${state.results.length === 1 ? "passage" : "passages"}` : ""}
          </span>
        )}
      </div>

      {state.status === "done" && !state.semantic && (
        <Notice tone="info">
          Meaning-based search needs the embedding model, which is not loaded. Results currently match shared words only.
          Run <code>python setup_nlp.py</code> on the server to enable it.
        </Notice>
      )}

      {state.status === "loading" && <Loading label="Searching" />}

      {state.status === "done" && !state.results.length && (
        <p className="muted" style={{ textAlign: "center", marginTop: 48 }}>
          No passages matched &ldquo;{state.asked}&rdquo;. Try different words or search all documents.
        </p>
      )}

      <div className="results">
        {state.status !== "loading" && state.results.map((r, i) => (
          <article key={`${r.doc_id}-${r.page}-${i}`} className="card result">
            <blockquote><Passage text={r.text} highlight={r.highlight} /></blockquote>
            <div className="score">
              <b>{percent(r.score)}</b> match
              <br />
              <Meter value={r.score} label={`Similarity ${percent(r.score)}`} />
            </div>
            <footer>
              <span>{r.doc_title} &bull; Page {r.page}</span>
              <Link to={`/?doc=${r.doc_id}`}>Open document</Link>
            </footer>
          </article>
        ))}
      </div>
    </div>
  );
}
