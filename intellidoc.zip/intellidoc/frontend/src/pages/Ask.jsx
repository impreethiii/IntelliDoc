import { ArrowUp, ChevronDown, ChevronRight, FileText } from "lucide-react";
import { Fragment, useEffect, useRef, useState } from "react";
import { api } from "../api";
import { DocSelect, EmptyState, Loading, Meter, Notice } from "../components/Common.jsx";
import { percent, plural, useDocuments, useSelectedDocId } from "../utils";

function AnswerText({ answer, span }) {
  const at = span ? answer.indexOf(span) : -1;
  if (at === -1) return answer;
  return (
    <Fragment>
      {answer.slice(0, at)}<mark>{span}</mark>{answer.slice(at + span.length)}
    </Fragment>
  );
}

function Answer({ item }) {
  const [open, setOpen] = useState(false);
  const found = Boolean(item.answer);
  return (
    <article className="card answer">
      <div className="answer-head">
        <b>IntelliDoc</b>
        {found && (
          <span className="conf" title="How strongly the document supports this answer">
            Confidence <Meter value={item.confidence} tone="amber" /> <strong style={{ fontWeight: 500, color: "var(--navy)" }}>{percent(item.confidence)}</strong>
          </span>
        )}
      </div>
      {found ? <p><AnswerText answer={item.answer} span={item.span} /></p> : <p className="none">{item.message}</p>}
      {item.sources?.length > 0 && (
        <>
          <button className="sources-toggle" onClick={() => setOpen(!open)} aria-expanded={open}>
            {open ? <ChevronDown size={16} /> : <ChevronRight size={16} />} Sources ({plural(item.sources.length, "passage")})
          </button>
          {open && (
            <div className="sources">
              {item.sources.map((s, i) => (
                <div key={i} className="source">
                  <div className="src-head"><span>{s.doc_title} &bull; Page {s.page}</span><span>{percent(s.score)} match</span></div>
                  {s.text}
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </article>
  );
}

export default function Ask() {
  const { docs, error: listError } = useDocuments();
  const [docId, selectDoc, ready] = useSelectedDocId(docs);
  const [doc, setDoc] = useState(null);
  const [thread, setThread] = useState([]);       // {q, a?}
  const [question, setQuestion] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const end = useRef(null);

  useEffect(() => {
    setThread([]);
    setDoc(null);
    if (docId) api.getDocument(docId).then(setDoc).catch((e) => setError(e.message));
  }, [docId]);

  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth", block: "nearest" }); }, [thread, busy]);

  const ask = async (text) => {
    const q = (text ?? question).trim();
    if (q.length < 3 || busy || !docId) return;
    setQuestion("");
    setError("");
    setBusy(true);
    setThread((t) => [...t, { q }]);
    try {
      const a = await api.ask(q, docId);
      setThread((t) => t.map((m, i) => (i === t.length - 1 ? { ...m, a } : m)));
    } catch (e) {
      setError(e.message);
      setThread((t) => t.slice(0, -1));
    } finally {
      setBusy(false);
    }
  };

  if (docs === null) return <Loading />;
  if (listError) return <Notice>{listError}</Notice>;
  if (!ready.length) {
    return <EmptyState title="Nothing to ask about yet" text="Upload a document, then ask questions and get answers taken from its text." />;
  }

  const lexical = thread.some((m) => m.a && m.a.semantic === false);

  return (
    <div className="narrow">
      <div className="card ask-doc">
        <div className="left">
          <FileText size={20} className="muted" />
          {ready.length > 1 ? <DocSelect docs={ready} value={docId} onChange={selectDoc} /> : <strong style={{ fontWeight: 500 }}>{doc?.title || ready[0].title}</strong>}
        </div>
        {doc && <span className="badge">{plural(doc.pages, "page")} indexed</span>}
      </div>

      {error && <Notice>{error}</Notice>}
      {lexical && (
        <Notice tone="info">
          The embedding model is not loaded, so passages are found by shared words rather than meaning. Run <code>python setup_nlp.py</code> on the server to enable it.
        </Notice>
      )}

      {thread.length === 0 && !busy && (
        <p className="muted" style={{ textAlign: "center", margin: "56px 0" }}>
          Ask a question and IntelliDoc will answer from the text of this document.
        </p>
      )}

      <div className="thread" aria-live="polite">
        {thread.map((m, i) => (
          <Fragment key={i}>
            <div className="bubble-user">{m.q}</div>
            {m.a ? <Answer item={m.a} /> : <p className="thinking">Reading the document...</p>}
          </Fragment>
        ))}
        <div ref={end} />
      </div>

      <div className="suggest">
        <span className="label">Try</span>
        {(doc?.suggested_questions || []).map((s) => (
          <button key={s} onClick={() => ask(s)} disabled={busy}>{s}</button>
        ))}
      </div>

      <form className="composer" onSubmit={(e) => { e.preventDefault(); ask(); }}>
        <input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="Ask a question about this document"
          aria-label="Your question"
          maxLength={500}
        />
        <button className="btn primary send" type="submit" disabled={busy || question.trim().length < 3} aria-label="Send question">
          <ArrowUp size={20} />
        </button>
      </form>
    </div>
  );
}
