"""The full processing pipeline run for every uploaded document."""
from __future__ import annotations

import logging
import re
import traceback

from . import config
from .db import repo
from .nlp.chunking import build_chunks
from .nlp.classify import classify_document
from .nlp.embeddings import get_embedder
from .nlp.entities import extract_entities, ner_engine_name, noun_vocabulary
from .nlp.extract import ExtractionError, extract_document
from .nlp.keywords import extract_keywords
from .nlp.preprocess import preprocessing_sample, split_sentences
from .nlp.qa import qa_engine_name
from .nlp.summarize import summarize
from .nlp.vectorstore import store

log = logging.getLogger("intellidoc.pipeline")

STAGES = ["Extract", "Preprocess", "Analyse", "Embed", "Index"]
STAGE_DETAIL = [
    "Reading text from the file",
    "Cleaning text and splitting passages",
    "Finding keywords and named entities",
    "Encoding passages as vectors",
    "Classifying, summarising and indexing",
]


def _progress(doc_id: str, stage: int, fraction: float = 0.0) -> None:
    pct = int(min(99, (stage + fraction) / len(STAGES) * 100))
    repo.update(
        doc_id,
        status="processing",
        stage=stage,
        stage_name=STAGES[stage],
        stage_detail=STAGE_DETAIL[stage],
        progress=pct,
    )


def build_preview(text: str, limit: int = 3200) -> str:
    paragraphs = [p for p in text.split("\n\n") if p.strip()]
    if len(paragraphs) <= 2:                       # PDF text often arrives as one big block
        sentences = split_sentences(text)
        paragraphs = [" ".join(sentences[i:i + 4]) for i in range(0, len(sentences), 4)]
    out, used = [], 0
    for p in paragraphs:
        if used + len(p) > limit and out:
            break
        out.append(p)
        used += len(p)
    return "\n\n".join(out)


def process_document(doc_id: str) -> None:
    doc = repo.get(doc_id)
    if doc is None:
        return
    path = config.UPLOAD_DIR / f"{doc_id}{doc['extension']}"
    try:
        # 1. Extract
        _progress(doc_id, 0)
        extracted = extract_document(path)
        text = extracted.text
        repo.update(
            doc_id, title=extracted.title, pages=extracted.page_count,
            word_count=len(text.split()), file_type=extracted.file_type,
        )

        # 2. Preprocess
        _progress(doc_id, 1)
        preprocessing = preprocessing_sample(text)
        chunks = build_chunks(extracted.pages, config.CHUNK_WORDS, config.CHUNK_OVERLAP_WORDS)
        if not chunks:
            raise ExtractionError("The document does not contain enough text to analyse.")

        # 3. Analyse
        _progress(doc_id, 2)
        nouns = noun_vocabulary(text)
        keywords = extract_keywords(text, nouns=nouns)
        entities = extract_entities(text, exclude_terms={w for k in extract_keywords(text, top_n=40, nouns=nouns) for w in k['term'].lower().split()})

        # 4. Embed
        _progress(doc_id, 3)
        embedder = get_embedder()
        vectors = embedder.encode([c["text"] for c in chunks])

        # 5. Index (classification + summaries need the vectors)
        _progress(doc_id, 4)
        category = classify_document(text, vectors, embedder)
        summaries = summarize(text, embedder)
        store.save(doc_id, chunks, vectors, embedder.name)

        top_terms = [k["term"] for k in keywords[:3]]
        suggestions = ["What is the main idea of this document?"]
        if len(top_terms) > 0:
            suggestions.append(f"What does the document say about {top_terms[0]}?")
        if len(top_terms) > 1:
            suggestions.append(f"What is {top_terms[1]}?")

        repo.update(
            doc_id,
            status="ready", stage=len(STAGES), stage_name="Done", stage_detail="Ready", progress=100,
            category=category, summary=summaries, keywords=keywords, entities=entities,
            preprocessing=preprocessing, preview=build_preview(text),
            suggested_questions=suggestions,
            engine={
                "embedding": embedder.name, "semantic": embedder.semantic,
                "ner": ner_engine_name(), "qa": qa_engine_name(), "vector_index": store.backend,
            },
            error=None,
        )
        log.info("Processed %s (%s chunks)", doc_id, len(chunks))
    except ExtractionError as exc:
        repo.update(doc_id, status="failed", error=str(exc))
    except Exception as exc:  # noqa: BLE001
        log.error("Pipeline failed for %s\n%s", doc_id, traceback.format_exc())
        repo.update(doc_id, status="failed", error=f"Processing failed: {exc}")
