"""Central configuration. Everything can be overridden with environment variables."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("INTELLIDOC_DATA_DIR", BASE_DIR / "data"))
UPLOAD_DIR = DATA_DIR / "uploads"
VECTOR_DIR = DATA_DIR / "vectors"
DOC_DIR = DATA_DIR / "documents"

for _d in (UPLOAD_DIR, VECTOR_DIR, DOC_DIR):
    _d.mkdir(parents=True, exist_ok=True)

MONGODB_URI = os.getenv("MONGODB_URI", "")
MONGODB_DB = os.getenv("MONGODB_DB", "intellidoc")

EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
QA_MODEL = os.getenv("QA_MODEL", "deepset/roberta-base-squad2")
SPACY_MODEL = os.getenv("SPACY_MODEL", "en_core_web_sm")

# Set INTELLIDOC_LIGHT=1 to skip the heavy transformer models (uses lexical fallbacks).
LIGHT_MODE = os.getenv("INTELLIDOC_LIGHT", "0") == "1"

MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "50"))
ALLOWED_EXTENSIONS = {".pdf", ".docx", ".txt"}

CHUNK_WORDS = int(os.getenv("CHUNK_WORDS", "110"))
CHUNK_OVERLAP_WORDS = int(os.getenv("CHUNK_OVERLAP_WORDS", "25"))

CORS_ORIGINS = os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",")
