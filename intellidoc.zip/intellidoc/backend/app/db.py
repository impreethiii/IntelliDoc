"""Document metadata storage: MongoDB when MONGODB_URI is set, otherwise JSON files."""
from __future__ import annotations

import json
import logging
import threading
from typing import Any

from . import config

log = logging.getLogger("intellidoc.db")


class _JsonRepo:
    kind = "local JSON files"

    def __init__(self) -> None:
        self._lock = threading.Lock()

    def _path(self, doc_id: str):
        return config.DOC_DIR / f"{doc_id}.json"

    def save(self, doc: dict) -> None:
        with self._lock:
            tmp = self._path(doc["id"]).with_suffix(".tmp")
            tmp.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")
            tmp.replace(self._path(doc["id"]))

    def get(self, doc_id: str) -> dict | None:
        p = self._path(doc_id)
        if not p.exists():
            return None
        with self._lock:
            return json.loads(p.read_text(encoding="utf-8"))

    def update(self, doc_id: str, **fields: Any) -> None:
        doc = self.get(doc_id)
        if doc is not None:
            doc.update(fields)
            self.save(doc)

    def list(self) -> list[dict]:
        docs = []
        for p in config.DOC_DIR.glob("*.json"):
            if p.name.endswith(".chunks.json"):
                continue
            try:
                docs.append(json.loads(p.read_text(encoding="utf-8")))
            except (json.JSONDecodeError, OSError):
                continue
        return sorted(docs, key=lambda d: d.get("uploaded_at", ""), reverse=True)

    def delete(self, doc_id: str) -> None:
        self._path(doc_id).unlink(missing_ok=True)


class _MongoRepo:
    kind = "MongoDB"

    def __init__(self, uri: str, db_name: str) -> None:
        from pymongo import MongoClient

        client = MongoClient(uri, serverSelectionTimeoutMS=3000)
        client.admin.command("ping")                     # raises if unreachable
        self._col = client[db_name]["documents"]

    def save(self, doc: dict) -> None:
        self._col.replace_one({"_id": doc["id"]}, {**doc, "_id": doc["id"]}, upsert=True)

    def get(self, doc_id: str) -> dict | None:
        d = self._col.find_one({"_id": doc_id})
        if d:
            d.pop("_id", None)
        return d

    def update(self, doc_id: str, **fields: Any) -> None:
        self._col.update_one({"_id": doc_id}, {"$set": fields})

    def list(self) -> list[dict]:
        return [{k: v for k, v in d.items() if k != "_id"} for d in self._col.find().sort("uploaded_at", -1)]

    def delete(self, doc_id: str) -> None:
        self._col.delete_one({"_id": doc_id})


def _build_repo():
    if config.MONGODB_URI:
        try:
            repo = _MongoRepo(config.MONGODB_URI, config.MONGODB_DB)
            log.info("Using MongoDB")
            return repo
        except Exception as exc:  # noqa: BLE001
            log.warning("MongoDB unavailable (%s). Falling back to JSON files.", exc)
    return _JsonRepo()


repo = _build_repo()
