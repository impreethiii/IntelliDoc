"""Step 1 - read text out of PDF / DOCX / TXT files."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ExtractedDocument:
    title: str
    pages: list[str]                      # cleaned text, one entry per page (or one for DOCX/TXT)
    file_type: str
    metadata: dict = field(default_factory=dict)

    @property
    def text(self) -> str:
        return "\n\n".join(self.pages)

    @property
    def page_count(self) -> int:
        return len(self.pages)


class ExtractionError(Exception):
    """Raised when a file cannot be read or contains no text."""


def clean_text(raw: str) -> str:
    """Repair line-break damage that PDF extraction leaves behind."""
    raw = raw.replace("\r\n", "\n").replace("\r", "\n").replace("\x00", "")
    raw = re.sub(r"(\w)-\n(?=[a-z])", r"\1", raw)          # re-join hyphenated words
    paragraphs = re.split(r"\n\s*\n", raw)
    cleaned = []
    for para in paragraphs:
        para = re.sub(r"\s*\n\s*", " ", para)
        para = re.sub(r"[ \t]{2,}", " ", para).strip()
        if para:
            cleaned.append(para)
    return "\n\n".join(cleaned)


def _guess_title(first_lines: list[str], fallback: str) -> str:
    for line in first_lines:
        line = line.strip()
        if 6 <= len(line) <= 160:
            return line
    return fallback


def _from_pdf(path: Path) -> ExtractedDocument:
    from pypdf import PdfReader

    try:
        reader = PdfReader(str(path))
    except Exception as exc:  # noqa: BLE001
        raise ExtractionError(f"Could not open this PDF: {exc}") from exc

    if reader.is_encrypted:
        try:
            reader.decrypt("")
        except Exception as exc:  # noqa: BLE001
            raise ExtractionError("This PDF is password protected.") from exc

    raw_pages = [(page.extract_text() or "") for page in reader.pages]
    pages = [clean_text(p) for p in raw_pages]
    if not any(p.strip() for p in pages):
        raise ExtractionError(
            "No text found in this PDF. It may be a scanned image - OCR is not supported yet."
        )

    meta_title = ""
    try:
        meta_title = (reader.metadata.title or "").strip() if reader.metadata else ""
    except Exception:  # noqa: BLE001
        pass
    first_lines = next((p.splitlines() for p in raw_pages if p.strip()), [])
    fallback = path.stem.replace("_", " ")
    title = meta_title if len(meta_title) > 5 and not meta_title.lower().endswith(".pdf") else _guess_title(first_lines, fallback)
    return ExtractedDocument(title=title, pages=pages, file_type="PDF")


def _from_docx(path: Path) -> ExtractedDocument:
    import docx

    try:
        document = docx.Document(str(path))
    except Exception as exc:  # noqa: BLE001
        raise ExtractionError(f"Could not open this Word file: {exc}") from exc

    paragraphs = [p.text.strip() for p in document.paragraphs if p.text.strip()]
    for table in document.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells if c.text.strip()]
            if cells:
                paragraphs.append(" | ".join(cells))
    if not paragraphs:
        raise ExtractionError("This Word file has no readable text.")

    core_title = (document.core_properties.title or "").strip()
    title = core_title if len(core_title) > 5 else _guess_title(paragraphs[:5], path.stem.replace("_", " "))
    return ExtractedDocument(title=title, pages=["\n\n".join(paragraphs)], file_type="DOCX")


def _from_txt(path: Path) -> ExtractedDocument:
    data = path.read_bytes()
    text = None
    for encoding in ("utf-8", "utf-16", "latin-1"):
        try:
            text = data.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    if text is None or not text.strip():
        raise ExtractionError("This text file is empty or unreadable.")
    first_lines = [l for l in text.splitlines() if l.strip()][:5]
    title = _guess_title(first_lines, path.stem.replace("_", " "))
    return ExtractedDocument(title=title, pages=[clean_text(text)], file_type="TXT")


def extract_document(path: Path) -> ExtractedDocument:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return _from_pdf(path)
    if suffix == ".docx":
        return _from_docx(path)
    if suffix == ".txt":
        return _from_txt(path)
    raise ExtractionError(f"Unsupported file type: {suffix}")
