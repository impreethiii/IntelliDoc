"""Keyword extraction with TF-IDF (scikit-learn)."""
from __future__ import annotations

import re

import numpy as np
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS, TfidfVectorizer

from .preprocess import split_sentences, strip_references

_TOKEN = r"(?u)\b[a-zA-Z][a-zA-Z\-]{2,}\b"

# Words that structure a document rather than describe its subject.
_STRUCTURAL = {
    "abstract", "introduction", "methodology", "method", "methods", "discussion", "conclusion",
    "conclusions", "references", "reference", "section", "figure", "fig", "table", "paper", "papers",
    "results", "result", "work", "propose", "proposed", "presented", "present", "shows", "show",
    "study", "using", "used", "use", "based", "al", "however", "new", "approach", "approaches",
    "chapter", "appendix", "acknowledgements", "acknowledgments", "future", "overall", "number",
}
_STOP = list(ENGLISH_STOP_WORDS | _STRUCTURAL)


def extract_keywords(text: str, top_n: int = 15, nouns: set[str] | None = None) -> list[dict]:
    text = strip_references(text)
    sentences = [s for s in split_sentences(text) if len(s.split()) >= 5]   # skip headings
    if len(sentences) < 3:
        sentences = [text]

    try:
        vec = TfidfVectorizer(
            ngram_range=(1, 2), stop_words=_STOP, token_pattern=_TOKEN,
            lowercase=True, sublinear_tf=True, max_df=0.85,
        )
        matrix = vec.fit_transform(sentences)
    except ValueError:
        return []

    scores = np.asarray(matrix.sum(axis=0)).ravel()
    terms = vec.get_feature_names_out()
    order = np.argsort(scores)[::-1][: top_n * 12]

    # Keep the strongest phrases. A bigram replaces the unigrams it contains, and a unigram is
    # skipped when a chosen bigram already contains it.
    def acceptable(term: str) -> bool:
        if nouns is None:
            return True
        if "-" in term:                      # keep technical names such as "U-Net", skip "low-contrast"
            m = re.search(re.escape(term), text, flags=re.IGNORECASE)
            return bool(m and re.search(r"[A-Z]", m.group(0)))
        return term.split()[-1] in nouns      # the head word of the phrase must be a noun

    chosen: list[tuple[str, float]] = []
    for idx in order:
        term, score = terms[idx], float(scores[idx])
        if not acceptable(term):
            continue
        words = term.split()
        if len(words) == 1:
            if any(term in kept.split() for kept, _ in chosen):
                continue
        else:
            chosen = [(k, sc) for k, sc in chosen if not (len(k.split()) == 1 and k in words)]
            if any(kept == term for kept, _ in chosen):
                continue
        chosen.append((term, score))
        if len(chosen) >= top_n:
            break
    lowered = text

    if not chosen:
        return []
    top = max(s for _, s in chosen) or 1.0
    results = []
    for term, score in sorted(chosen, key=lambda x: -x[1]):
        match = re.search(re.escape(term).replace(r"\ ", r"\s+"), lowered, flags=re.IGNORECASE)
        surface = match.group(0) if match else term
        if surface.islower() and len(surface) <= 4:
            surface = surface.upper() if surface in {"mri", "ct", "cnn", "gpu", "nlp"} else surface
        results.append({"term": surface, "score": round(score / top, 3)})
    return results
