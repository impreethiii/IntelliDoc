"""Split a document into overlapping passages that keep their page number."""
from __future__ import annotations

from .preprocess import split_sentences


def _is_heading(sentence: str) -> bool:
    """'3. Datasets and Evaluation' - short, no closing punctuation. Keeps passages clean."""
    return len(sentence.split()) <= 8 and not sentence.rstrip().endswith((".", "!", "?", ":", ";", '"', ")"))


def build_chunks(pages: list[str], chunk_words: int = 110, overlap_words: int = 25) -> list[dict]:
    chunks: list[dict] = []
    for page_no, page_text in enumerate(pages, start=1):
        sentences = [s for s in split_sentences(page_text) if not _is_heading(s)]
        i = 0
        while i < len(sentences):
            words = 0
            j = i
            while j < len(sentences) and (words < chunk_words or j == i):
                words += len(sentences[j].split())
                j += 1
            text = " ".join(sentences[i:j]).strip()
            if len(text.split()) >= 5:
                chunks.append({"id": len(chunks), "page": page_no, "text": text})
            if j >= len(sentences):
                break
            # step back so neighbouring chunks share about `overlap_words` words
            back, carried = j, 0
            while back > i + 1 and carried < overlap_words:
                back -= 1
                carried += len(sentences[back].split())
            i = max(back, i + 1)
    return chunks
