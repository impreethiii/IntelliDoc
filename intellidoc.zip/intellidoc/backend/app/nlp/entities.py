"""Named Entity Recognition with spaCy (regex fallback if the model is missing)."""
from __future__ import annotations

import logging
import re
import threading
from collections import Counter, defaultdict

from .. import config
from .preprocess import strip_references

log = logging.getLogger("intellidoc.entities")

_lock = threading.Lock()
_nlp = None
_tried = False

LABEL_MAP = {
    "PERSON": "Person",
    "ORG": "Organization",
    "GPE": "Location",
    "LOC": "Location",
    "FAC": "Location",
    "DATE": "Date",
}
GROUPS = ["Person", "Organization", "Location", "Date"]


def _get_nlp():
    global _nlp, _tried
    if _tried:
        return _nlp
    with _lock:
        if not _tried:
            try:
                import spacy

                _nlp = spacy.load(config.SPACY_MODEL, disable=["lemmatizer"])
                _nlp.max_length = 2_000_000
            except Exception as exc:  # noqa: BLE001
                log.warning("spaCy model unavailable (%s). Using regex fallback.", exc)
                _nlp = None
            _tried = True
    return _nlp


def ner_engine_name() -> str:
    return f"spaCy {config.SPACY_MODEL}" if _get_nlp() is not None else "regex-fallback"


_YEAR = re.compile(r"\b(?:19|20)\d{2}\b")
_DATE = re.compile(
    r"\b(?:\d{1,2}\s+)?(?:January|February|March|April|May|June|July|August|September|October|November|December)"
    r"(?:\s+\d{1,2},?)?(?:\s+(?:19|20)\d{2})?\b"
)
_ORG = re.compile(
    r"\b(?:[A-Z][\w&\-]+\s+){0,3}(?:University|Institute|College|Hospital|Laboratory|Corporation|Company|Inc|Ltd|Council|Association|Agency)\b(?:\s+of\s+(?:[A-Z][\w\-]+\s?){1,3})?"
)
_PERSON = re.compile(r"\b(?:Dr|Prof|Mr|Mrs|Ms)\.?\s+(?:[A-Z][a-z]+\s?){1,3}")


def _regex_entities(text: str) -> list[tuple[str, str]]:
    found: list[tuple[str, str]] = []
    found += [(m.group(0).strip(), "Date") for m in _DATE.finditer(text)]
    found += [(m.group(0), "Date") for m in _YEAR.finditer(text)]
    found += [(m.group(0).strip(), "Organization") for m in _ORG.finditer(text)]
    found += [(m.group(0).strip(), "Person") for m in _PERSON.finditer(text)]
    return found


def _clean(text: str) -> str:
    text = re.sub(r"\s+", " ", text).strip(" ,.;:()[]\"'")
    return re.sub(r"^(the|a|an)\s+", "", text, flags=re.IGNORECASE)


def noun_vocabulary(text: str) -> set[str] | None:
    """Lower-case words that are mostly used as nouns in this document (None if spaCy is missing)."""
    nlp = _get_nlp()
    if nlp is None:
        return None
    from collections import Counter as _C

    noun, other = _C(), _C()
    batches = [p[:5000] for p in strip_references(text).split("\n\n") if p.strip()]
    for doc in nlp.pipe(batches, batch_size=16, disable=["ner", "parser"]):
        for tok in doc:
            if not tok.is_alpha:
                continue
            (noun if tok.pos_ in ("NOUN", "PROPN") else other)[tok.text.lower()] += 1
    return {w for w, c in noun.items() if c >= other[w]}


def _body_for_ner(text: str) -> str:
    """Drop the title line and the reference list - they produce a lot of false entities."""
    paragraphs = strip_references(text).split("\n\n")
    if len(paragraphs) > 2 and len(paragraphs[0].split()) <= 20 and not paragraphs[0].rstrip().endswith("."):
        paragraphs = paragraphs[1:]
    return "\n\n".join(paragraphs)


def _looks_technical(value: str) -> bool:
    """Model names, acronyms and camel-case terms are rarely people/places/organisations."""
    if " " in value:
        return False
    if "-" in value or re.search(r"[a-z][A-Z]", value) or re.search(r"\d", value):
        return True
    return value.isupper() and len(value) <= 3


def extract_entities(text: str, per_group: int = 12, exclude_terms: set[str] | None = None) -> dict[str, list[dict]]:
    exclude_terms = {t.lower() for t in (exclude_terms or set())}
    text = _body_for_ner(text)
    nlp = _get_nlp()
    pairs: list[tuple[str, str]] = []
    if nlp is not None:
        paragraphs = [p for p in re.split(r"\n\s*\n", text) if p.strip()]
        # keep each spaCy call small and fast
        batches = [p[:5000] for p in paragraphs] or [text[:5000]]
        for doc in nlp.pipe(batches, batch_size=16):
            for ent in doc.ents:
                group = LABEL_MAP.get(ent.label_)
                if group:
                    pairs.append((ent.text, group))
    else:
        pairs = _regex_entities(text)

    counts: dict[str, Counter] = defaultdict(Counter)
    canonical: dict[tuple[str, str], str] = {}
    for raw, group in pairs:
        value = _clean(raw)
        if len(value) < 2 or value.isdigit() and group != "Date":
            continue
        if group == "Date" and not re.search(r"\d", value):
            continue                       # "today", "recent years" etc. are not useful
        if group == "Person" and (len(value.split()) < 2 and len(value) < 4):
            continue
        if re.search(r"\bet al\b", value, flags=re.IGNORECASE) or re.match(r"^[A-Z]\.\s", value):
            continue
        if group != "Date" and (_looks_technical(value) or (" " not in value and value.lower() in exclude_terms)):
            continue
        key = (group, value.lower())
        canonical.setdefault(key, value)
        counts[group][value.lower()] += 1

    result: dict[str, list[dict]] = {}
    for group in GROUPS:
        items = [
            {"text": canonical[(group, k)], "count": c}
            for k, c in counts[group].most_common(per_group)
        ]
        result[group] = items
    return result
