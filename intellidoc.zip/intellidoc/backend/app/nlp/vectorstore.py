"""Stores passage embeddings per document and searches across them (FAISS if installed)."""
from __future__ import annotations

import json
import threading

import numpy as np

from .. import config
from .embeddings import Embedder

try:  # optional
    import faiss  # type: ignore
except Exception:  # noqa: BLE001
    faiss = None


def _chunks_path(doc_id: str):
    return config.DOC_DIR / f"{doc_id}.chunks.json"


def _vec_path(doc_id: str):
    return config.VECTOR_DIR / f"{doc_id}.npy"


class VectorStore:
    def __init__(self) -> None:
        self._cache: dict[str, tuple[list[dict], np.ndarray, str]] = {}
        self._lock = threading.Lock()

    @property
    def backend(self) -> str:
        return "FAISS" if faiss is not None else "NumPy"

    def save(self, doc_id: str, chunks: list[dict], vectors: np.ndarray, embedder_name: str) -> None:
        _chunks_path(doc_id).write_text(
            json.dumps({"embedder": embedder_name, "chunks": chunks}), encoding="utf-8"
        )
        np.save(_vec_path(doc_id), vectors)
        with self._lock:
            self._cache[doc_id] = (chunks, vectors, embedder_name)

    def load(self, doc_id: str, embedder: Embedder) -> tuple[list[dict], np.ndarray] | None:
        with self._lock:
            hit = self._cache.get(doc_id)
        if hit is None:
            cp, vp = _chunks_path(doc_id), _vec_path(doc_id)
            if not cp.exists():
                return None
            payload = json.loads(cp.read_text(encoding="utf-8"))
            vectors = np.load(vp) if vp.exists() else None
            hit = (payload["chunks"], vectors, payload.get("embedder", ""))
        chunks, vectors, name = hit
        if vectors is None or name != embedder.name:
            # The embedding model changed since upload - rebuild vectors from stored text.
            vectors = embedder.encode([c["text"] for c in chunks])
            self.save(doc_id, chunks, vectors, embedder.name)
        else:
            with self._lock:
                self._cache[doc_id] = (chunks, vectors, name)
        return chunks, vectors

    def delete(self, doc_id: str) -> None:
        with self._lock:
            self._cache.pop(doc_id, None)
        for p in (_chunks_path(doc_id), _vec_path(doc_id)):
            p.unlink(missing_ok=True)

    def search(self, query_vec: np.ndarray, doc_ids: list[str], embedder: Embedder, top_k: int = 5) -> list[dict]:
        all_chunks: list[dict] = []
        matrices: list[np.ndarray] = []
        for doc_id in doc_ids:
            loaded = self.load(doc_id, embedder)
            if not loaded:
                continue
            chunks, vectors = loaded
            for c in chunks:
                all_chunks.append({**c, "doc_id": doc_id})
            matrices.append(vectors)
        if not matrices:
            return []

        matrix = np.vstack(matrices).astype(np.float32)
        q = query_vec.reshape(1, -1).astype(np.float32)
        k = min(top_k, len(all_chunks))
        if faiss is not None:
            index = faiss.IndexFlatIP(matrix.shape[1])
            index.add(matrix)
            scores, ids = index.search(q, k)
            pairs = [(int(i), float(s)) for i, s in zip(ids[0], scores[0]) if i >= 0]
        else:
            sims = (matrix @ q.T).ravel()
            top = np.argsort(sims)[::-1][:k]
            pairs = [(int(i), float(sims[i])) for i in top]
        return [{**all_chunks[i], "score": s} for i, s in pairs]


store = VectorStore()
