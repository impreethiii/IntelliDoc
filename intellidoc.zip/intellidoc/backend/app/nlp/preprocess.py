"""Step 2 - NLP preprocessing: sentence split, tokenize, stop-word removal, lemmatization."""
from __future__ import annotations

import re
import threading

_lock = threading.Lock()
_ready = False
_stop: set[str] = set()
_lemmatizer = None
_sent_tokenize = None

_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z\-']*[A-Za-z]|[A-Za-z]|\d+(?:\.\d+)?%?")


def _init() -> None:
    global _ready, _stop, _lemmatizer, _sent_tokenize
    if _ready:
        return
    with _lock:
        if _ready:
            return
        try:
            from nltk.corpus import stopwords
            _stop = set(stopwords.words("english"))
        except Exception:  # noqa: BLE001
            from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
            _stop = set(ENGLISH_STOP_WORDS)
        try:
            from nltk.stem import WordNetLemmatizer
            lem = WordNetLemmatizer()
            lem.lemmatize("tests")           # raises LookupError if wordnet is missing
            _lemmatizer = lem
        except Exception:  # noqa: BLE001
            _lemmatizer = None
        try:
            from nltk.tokenize import sent_tokenize
            sent_tokenize("Test one. Test two.")
            _sent_tokenize = sent_tokenize
        except Exception:  # noqa: BLE001
            _sent_tokenize = None
        _ready = True


def strip_references(text: str) -> str:
    """Remove the bibliography - it adds author names that are not about the document's subject."""
    return re.split(r"\n\s*(?:references|bibliography)\s*\n", text, maxsplit=1, flags=re.IGNORECASE)[0]


def split_sentences(text: str) -> list[str]:
    """Sentence split that never lets a heading or paragraph run into the next one."""
    _init()
    out: list[str] = []
    for para in re.split(r"\n\s*\n", text):
        para = re.sub(r"\s+", " ", para).strip()
        if not para:
            continue
        if _sent_tokenize is not None:
            parts = _sent_tokenize(para)
        else:
            parts = re.split(r"(?<=[.!?])\s+(?=[A-Z\"'(])", para)
        out.extend(s.strip() for s in parts if s.strip())
    return out


def tokenize(text: str) -> list[str]:
    return _TOKEN_RE.findall(text)


def remove_stopwords(tokens: list[str]) -> list[str]:
    _init()
    return [t for t in tokens if t.lower() not in _stop]


def lemmatize(tokens: list[str]) -> list[str]:
    _init()
    if _lemmatizer is None:
        return [t.lower() for t in tokens]
    out = []
    for tok in tokens:
        low = tok.lower()
        verb = _lemmatizer.lemmatize(low, pos="v")
        out.append(verb if verb != low else _lemmatizer.lemmatize(low, pos="n"))
    return out


def preprocessing_sample(text: str, max_sentences: int = 3) -> dict:
    """Before/after view shown on the Preprocessing tab."""
    sentences = [s for s in split_sentences(text) if 8 <= len(s.split()) <= 60]
    original = " ".join(sentences[1:1 + max_sentences] or sentences[:max_sentences])
    tokens = tokenize(original)
    no_stop = remove_stopwords(tokens)
    lemmas = lemmatize(no_stop)

    all_tokens = tokenize(text)
    all_clean = remove_stopwords(all_tokens)
    return {
        "original": original,
        "tokens": tokens,
        "no_stopwords": no_stop,
        "lemmas": lemmas,
        "stats": {
            "sentences": len(split_sentences(text)),
            "tokens": len(all_tokens),
            "after_stopwords": len(all_clean),
            "unique_lemmas": len(set(lemmatize(all_clean))),
        },
    }
