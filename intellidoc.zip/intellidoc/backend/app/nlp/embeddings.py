"""Text embeddings.

Primary:  Sentence-Transformers (all-MiniLM-L6-v2) - understands meaning.
Fallback: hashed word/bigram vectors - lexical only. Used when the model cannot be loaded
          (no internet on first run, or INTELLIDOC_LIGHT=1). The app still works, but search
          then matches shared words rather than shared meaning.
"""
from __future__ import annotations

import logging
import threading

import numpy as np

from .. import config

log = logging.getLogger("intellidoc.embeddings")

_lock = threading.Lock()
_instance: "Embedder | None" = None


class Embedder:
    def __init__(self) -> None:
        self.model = None
        self.semantic = False
        self.name = "hashed-lexical"
        self.min_score = 0.10          # lowest similarity still shown as a search hit
        self._hasher = None

        if not config.LIGHT_MODE:
            try:
                from sentence_transformers import SentenceTransformer

                self.model = SentenceTransformer(config.EMBEDDING_MODEL)
                self.semantic = True
                self.name = config.EMBEDDING_MODEL
                self.min_score = 0.25
                log.info("Loaded embedding model %s", self.name)
            except Exception as exc:  # noqa: BLE001
                log.warning("Embedding model unavailable (%s). Using lexical fallback.", exc)

        if self.model is None:
            from sklearn.feature_extraction.text import HashingVectorizer

            self._hasher = HashingVectorizer(
                n_features=16384, alternate_sign=False, norm="l2",
                ngram_range=(1, 2), stop_words="english",
                token_pattern=r"(?u)\b[a-zA-Z][a-zA-Z\-]{2,}\b", lowercase=True,
            )

    def encode(self, texts: list[str]) -> np.ndarray:
        if not texts:
            return np.zeros((0, 1), dtype=np.float32)
        if self.model is not None:
            vecs = self.model.encode(
                texts, batch_size=32, convert_to_numpy=True,
                normalize_embeddings=True, show_progress_bar=False,
            )
            return vecs.astype(np.float32)
        return self._hasher.transform(texts).toarray().astype(np.float32)


def get_embedder() -> Embedder:
    global _instance
    if _instance is None:
        with _lock:
            if _instance is None:
                _instance = Embedder()
    return _instance
