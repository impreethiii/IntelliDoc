"""Extractive summarisation: rank sentences with TextRank + closeness to the document centroid.

Every sentence in the summary is copied from the document, so nothing is invented.
"""
from __future__ import annotations

import re

import numpy as np

from .embeddings import Embedder
from .preprocess import split_sentences

MAX_SENTENCES = 1500


def _good_sentence(s: str) -> bool:
    words = s.split()
    if not 8 <= len(words) <= 70:
        return False
    if re.match(r"^\s*(\[\d+\]|\d+\.\s|fig\.|figure|table)\b", s, flags=re.IGNORECASE):
        return False
    letters = sum(ch.isalpha() for ch in s)
    return letters / max(len(s), 1) > 0.6


def _textrank(sim: np.ndarray, damping: float = 0.85, iters: int = 40) -> np.ndarray:
    sim = np.clip(sim, 0, None)
    np.fill_diagonal(sim, 0)
    row = sim.sum(axis=1, keepdims=True)
    row[row == 0] = 1.0
    trans = sim / row
    n = sim.shape[0]
    rank = np.full(n, 1.0 / n)
    for _ in range(iters):
        rank = (1 - damping) / n + damping * trans.T @ rank
    return rank


def summarize(text: str, embedder: Embedder, short: int = 3, detailed: int = 7) -> dict:
    sentences = [s for s in split_sentences(text) if _good_sentence(s)][:MAX_SENTENCES]
    if not sentences:
        fallback = text[:400].strip()
        return {"short": fallback, "detailed": fallback}
    if len(sentences) <= short:
        joined = " ".join(sentences)
        return {"short": joined, "detailed": joined}

    vecs = embedder.encode(sentences)
    centroid = vecs.mean(axis=0)
    centroid /= np.linalg.norm(centroid) or 1.0
    centrality = vecs @ centroid
    rank = _textrank(vecs @ vecs.T)

    def norm(x: np.ndarray) -> np.ndarray:
        span = x.max() - x.min()
        return (x - x.min()) / span if span else np.zeros_like(x)

    position = np.linspace(0.15, 0.0, len(sentences))      # slight lead bias
    score = 0.5 * norm(rank) + 0.4 * norm(centrality) + position

    def pick(k: int) -> str:
        chosen: list[int] = []
        for idx in np.argsort(score)[::-1]:
            # skip near-duplicates of something already chosen
            if all(float(vecs[idx] @ vecs[j]) < 0.85 for j in chosen):
                chosen.append(int(idx))
            if len(chosen) >= k:
                break
        return " ".join(sentences[i] for i in sorted(chosen))

    return {"short": pick(short), "detailed": pick(min(detailed, len(sentences)))}
