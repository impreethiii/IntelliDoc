"""Question answering over retrieved passages.

With the transformers model available we run extractive QA (the answer is a span copied from
the document). Without it we return the sentence most similar to the question.
If nothing relevant is found we say so instead of guessing.
"""
from __future__ import annotations

import logging
import re
import threading

import numpy as np

from .. import config
from .embeddings import Embedder
from .preprocess import split_sentences

log = logging.getLogger("intellidoc.qa")

_lock = threading.Lock()
_pipe = None
_tried = False


def _get_pipe():
    global _pipe, _tried
    if _tried:
        return _pipe
    with _lock:
        if not _tried:
            if not config.LIGHT_MODE:
                try:
                    from transformers import pipeline

                    _pipe = pipeline("question-answering", model=config.QA_MODEL)
                    log.info("Loaded QA model %s", config.QA_MODEL)
                except Exception as exc:  # noqa: BLE001
                    log.warning("QA model unavailable (%s). Using sentence retrieval.", exc)
                    _pipe = None
            _tried = True
    return _pipe


def qa_engine_name() -> str:
    return config.QA_MODEL if _get_pipe() is not None else "sentence-retrieval"


def _sentence_with_span(context: str, start: int, end: int) -> str:
    pos = 0
    for sent in split_sentences(context):
        idx = context.find(sent, pos)
        if idx == -1:
            continue
        if idx <= start < idx + len(sent):
            return sent
        pos = idx + len(sent)
    return context[max(0, start - 80): end + 80]


def answer_question(question: str, passages: list[dict], embedder: Embedder) -> dict:
    """`passages` are retrieval hits sorted by similarity (best first)."""
    if not passages or passages[0]["score"] < embedder.min_score:
        return {
            "answer": None,
            "confidence": 0.0,
            "message": "I could not find this in the document. Try rephrasing the question.",
            "sources": passages[:3],
        }

    pipe = _get_pipe()
    if pipe is not None:
        best = None
        for p in passages[:4]:
            try:
                out = pipe(question=question, context=p["text"], handle_impossible_answer=True)
            except Exception as exc:  # noqa: BLE001
                log.warning("QA failed on passage: %s", exc)
                continue
            if not out.get("answer", "").strip():
                continue
            if best is None or out["score"] > best[0]["score"]:
                best = (out, p)
        if best is None or best[0]["score"] < 0.05:
            return {
                "answer": None,
                "confidence": 0.0,
                "message": "The document does not seem to answer this question.",
                "sources": passages[:3],
            }
        out, passage = best
        sentence = _sentence_with_span(passage["text"], out["start"], out["end"])
        return {
            "answer": sentence,
            "span": out["answer"].strip(),
            "confidence": round(float(out["score"]), 3),
            "sources": passages[:3],
        }

    # Fallback: choose the single most question-like sentence from the best passages.
    candidates: list[tuple[str, dict]] = []
    seen: set[str] = set()
    for p in passages[:3]:
        for s in split_sentences(p["text"]):
            if len(s.split()) >= 5 and s not in seen:
                seen.add(s)
                candidates.append((s, p))
    if not candidates:
        return {"answer": None, "confidence": 0.0, "message": "No readable passage found.", "sources": passages[:3]}
    q_vec = embedder.encode([question])[0]
    s_vecs = embedder.encode([c[0] for c in candidates])
    sims = s_vecs @ q_vec
    order = np.argsort(sims)[::-1]
    best = float(sims[order[0]])
    top_sentences = [candidates[order[0]][0]]
    if len(order) > 1 and float(sims[order[1]]) >= 0.75 * best:      # add a 2nd sentence only if equally relevant
        top_sentences.append(candidates[order[1]][0])
    return {
        "answer": " ".join(top_sentences),
        "span": None,
        "confidence": round(float(max(0.0, sims[order[0]])), 3),
        "sources": passages[:3],
    }
