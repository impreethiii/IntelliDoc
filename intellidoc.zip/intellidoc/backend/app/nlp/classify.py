"""Document type classification.

Each category is described in plain words. The document embedding is compared with every
description (cosine similarity), then nudged by a few structural cues such as the presence
of 'abstract' or 'references'. Scores become probabilities with a softmax.
"""
from __future__ import annotations

import re

import numpy as np

from .embeddings import Embedder

CATEGORIES: dict[str, str] = {
    "Research Paper": (
        "abstract introduction methodology experiments results discussion conclusion references "
        "we propose a novel approach, evaluated on datasets, accuracy, baseline comparison, authors et al."
    ),
    "Technical Document": (
        "technical documentation system architecture installation configuration api implementation "
        "specification requirements module software hardware design steps procedure manual"
    ),
    "Business Report": (
        "annual report quarterly revenue profit market growth strategy customers sales budget "
        "financial performance stakeholders executive summary forecast"
    ),
    "Legal Document": (
        "agreement contract clause party parties hereby liability terms and conditions jurisdiction "
        "obligations law act section court rights warranty"
    ),
    "News Article": (
        "reported yesterday according to officials said on monday government police minister "
        "announced local news correspondent statement"
    ),
    "Educational Material": (
        "lecture notes chapter students learning course syllabus exercises definition example "
        "explain concept tutorial textbook exam"
    ),
}

_CUES: dict[str, list[tuple[str, float]]] = {
    "Research Paper": [
        (r"\babstract\b", 0.06), (r"\breferences\b", 0.05), (r"\bet al\.", 0.06),
        (r"\bdataset", 0.03), (r"\bexperiment", 0.03), (r"\bwe propose\b", 0.05),
        (r"\bmethodology\b", 0.03), (r"\bbaseline", 0.03),
    ],
    "Technical Document": [(r"\binstallation\b", 0.05), (r"\bconfiguration\b", 0.04), (r"\bapi\b", 0.03)],
    "Business Report": [(r"\brevenue\b", 0.05), (r"\bquarter", 0.04), (r"\bshareholder", 0.05)],
    "Legal Document": [(r"\bhereby\b", 0.06), (r"\bwhereas\b", 0.06), (r"\bindemnif", 0.06)],
    "News Article": [(r"\baccording to\b", 0.03), (r"\bsaid on\b", 0.05)],
    "Educational Material": [(r"\blecture\b", 0.05), (r"\bexercise", 0.04), (r"\bchapter\b", 0.04)],
}

_proto_cache: dict[str, np.ndarray] = {}


def _prototypes(embedder: Embedder) -> tuple[list[str], np.ndarray]:
    labels = list(CATEGORIES)
    if embedder.name not in _proto_cache:
        _proto_cache[embedder.name] = embedder.encode([CATEGORIES[l] for l in labels])
    return labels, _proto_cache[embedder.name]


def classify_document(text: str, chunk_vectors: np.ndarray, embedder: Embedder) -> dict:
    labels, protos = _prototypes(embedder)
    centroid = chunk_vectors.mean(axis=0)
    norm = np.linalg.norm(centroid) or 1.0
    sims = protos @ (centroid / norm)

    sample = text[:20000].lower()
    bonus = np.zeros(len(labels))
    for i, label in enumerate(labels):
        for pattern, weight in _CUES.get(label, []):
            if re.search(pattern, sample):
                bonus[i] += weight
    scores = sims + bonus

    temperature = 0.10
    z = (scores - scores.max()) / temperature
    probs = np.exp(z) / np.exp(z).sum()
    order = np.argsort(probs)[::-1]
    return {
        "label": labels[order[0]],
        "confidence": round(min(float(probs[order[0]]), 0.99), 3),
        "alternatives": [
            {"label": labels[i], "confidence": round(float(probs[i]), 3)} for i in order[1:3]
        ],
    }
