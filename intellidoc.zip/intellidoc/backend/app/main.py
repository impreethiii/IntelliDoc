"""IntelliDoc API.  Run with:  uvicorn app.main:app --reload"""
from __future__ import annotations

import logging
import re
import threading
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import config
from .db import repo
from .nlp.embeddings import get_embedder
from .nlp.entities import ner_engine_name
from .nlp.preprocess import split_sentences
from .nlp.qa import answer_question, qa_engine_name
from .nlp.vectorstore import store
from .pipeline import STAGES, process_document

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s  %(message)s")
log = logging.getLogger("intellidoc")


def _warm_up() -> None:
    """Load the heavy models in the background so the first upload is not slow."""
    try:
        get_embedder()
        ner_engine_name()
        qa_engine_name()
        log.info("Models ready")
    except Exception as exc:  # noqa: BLE001
        log.warning("Warm-up problem: %s", exc)


@asynccontextmanager
async def lifespan(_: FastAPI):
    threading.Thread(target=_warm_up, daemon=True).start()
    yield


app = FastAPI(title="IntelliDoc API", version="1.0.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware, allow_origins=config.CORS_ORIGINS, allow_methods=["*"], allow_headers=["*"],
)

LIST_FIELDS = (
    "id", "title", "filename", "file_type", "size_bytes", "pages", "word_count", "uploaded_at",
    "status", "stage", "stage_name", "stage_detail", "progress", "error", "category",
)


def _brief(doc: dict) -> dict:
    return {k: doc.get(k) for k in LIST_FIELDS}


def _public(doc: dict) -> dict:
    return {k: v for k, v in doc.items() if k != "extension"}


def _get_or_404(doc_id: str) -> dict:
    doc = repo.get(doc_id)
    if doc is None:
        raise HTTPException(404, "Document not found")
    return doc


# --------------------------------------------------------------------------- health
@app.get("/api/health")
def health():
    e = get_embedder()
    return {
        "status": "ok",
        "storage": repo.kind,
        "stages": STAGES,
        "engines": {
            "embedding": e.name, "semantic_search": e.semantic,
            "ner": ner_engine_name(), "qa": qa_engine_name(), "vector_index": store.backend,
        },
    }


# --------------------------------------------------------------------------- documents
@app.post("/api/documents", status_code=202)
async def upload_document(background: BackgroundTasks, file: UploadFile = File(...)):
    filename = Path(file.filename or "document").name
    ext = Path(filename).suffix.lower()
    if ext not in config.ALLOWED_EXTENSIONS:
        raise HTTPException(400, "Unsupported file type. Please upload a PDF, DOCX or TXT file.")

    doc_id = uuid.uuid4().hex[:12]
    dest = config.UPLOAD_DIR / f"{doc_id}{ext}"
    limit = config.MAX_UPLOAD_MB * 1024 * 1024
    size = 0
    with dest.open("wb") as out:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > limit:
                out.close()
                dest.unlink(missing_ok=True)
                raise HTTPException(413, f"File is larger than {config.MAX_UPLOAD_MB} MB.")
            out.write(chunk)
    if size == 0:
        dest.unlink(missing_ok=True)
        raise HTTPException(400, "The uploaded file is empty.")

    doc = {
        "id": doc_id, "filename": filename, "extension": ext,
        "title": Path(filename).stem.replace("_", " "),
        "file_type": ext.lstrip(".").upper(), "size_bytes": size, "pages": None, "word_count": None,
        "uploaded_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "status": "processing", "stage": 0, "stage_name": STAGES[0],
        "stage_detail": "Waiting to start", "progress": 0, "error": None, "category": None,
    }
    repo.save(doc)
    background.add_task(process_document, doc_id)
    return _brief(doc)


@app.get("/api/documents")
def list_documents():
    return [_brief(d) for d in repo.list()]


@app.get("/api/documents/{doc_id}")
def get_document(doc_id: str):
    return _public(_get_or_404(doc_id))


@app.delete("/api/documents/{doc_id}", status_code=204)
def delete_document(doc_id: str):
    doc = _get_or_404(doc_id)
    (config.UPLOAD_DIR / f"{doc_id}{doc.get('extension', '')}").unlink(missing_ok=True)
    store.delete(doc_id)
    repo.delete(doc_id)


# --------------------------------------------------------------------------- search
class SearchRequest(BaseModel):
    query: str = Field(min_length=2, max_length=500)
    document_id: str | None = None
    top_k: int = Field(default=5, ge=1, le=20)


def _target_docs(document_id: str | None) -> list[dict]:
    if document_id:
        doc = _get_or_404(document_id)
        if doc.get("status") != "ready":
            raise HTTPException(409, "This document is still being processed.")
        return [doc]
    return [d for d in repo.list() if d.get("status") == "ready"]


def _public_hit(hit: dict, titles: dict[str, str], limit: int = 1200) -> dict:
    text = hit["text"]
    if len(text) > limit:                      # cut on a sentence boundary, never mid-word
        cut = text[:limit]
        text = cut[: cut.rfind(". ") + 1] if ". " in cut else cut.rsplit(" ", 1)[0]
    return {
        "doc_id": hit["doc_id"], "doc_title": titles.get(hit["doc_id"], ""),
        "page": hit["page"], "text": text, "score": round(max(0.0, hit["score"]), 3),
    }


@app.post("/api/search")
def semantic_search(req: SearchRequest):
    docs = _target_docs(req.document_id)
    titles = {d["id"]: d.get("title", "") for d in docs}
    embedder = get_embedder()
    q_vec = embedder.encode([req.query])[0]
    hits = store.search(q_vec, [d["id"] for d in docs], embedder, top_k=req.top_k)
    hits = [h for h in hits if h["score"] >= embedder.min_score]

    results = []
    for hit in hits:
        item = _public_hit(hit, titles)
        # highlight the single sentence that best answers the query
        sentences = split_sentences(item["text"])
        if len(sentences) > 1:
            sims = embedder.encode(sentences) @ q_vec
            item["highlight"] = sentences[int(sims.argmax())]
        else:
            item["highlight"] = sentences[0] if sentences else item["text"]
        results.append(item)
    return {"query": req.query, "semantic": embedder.semantic, "results": results}


# --------------------------------------------------------------------------- question answering
class AskRequest(BaseModel):
    question: str = Field(min_length=3, max_length=500)
    document_id: str | None = None


@app.post("/api/ask")
def ask(req: AskRequest):
    docs = _target_docs(req.document_id)
    titles = {d["id"]: d.get("title", "") for d in docs}
    embedder = get_embedder()
    q_vec = embedder.encode([req.question])[0]
    hits = store.search(q_vec, [d["id"] for d in docs], embedder, top_k=5)
    result = answer_question(req.question, hits, embedder)
    result["sources"] = [_public_hit(h, titles) for h in result["sources"]]
    result["semantic"] = embedder.semantic
    return result


# --------------------------------------------------------------------------- serve the built frontend (optional)
_dist = config.BASE_DIR.parent / "frontend" / "dist"
if _dist.exists():
    app.mount("/assets", StaticFiles(directory=_dist / "assets"), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        if path.startswith("api/"):
            raise HTTPException(404)
        candidate = _dist / path
        return FileResponse(candidate if candidate.is_file() else _dist / "index.html")
