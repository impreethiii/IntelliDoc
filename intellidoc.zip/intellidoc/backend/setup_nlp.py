"""One-time download of NLP resources. Run:  python setup_nlp.py"""
import subprocess
import sys

import nltk

for pkg in ["punkt", "punkt_tab", "stopwords", "wordnet", "omw-1.4"]:
    nltk.download(pkg, quiet=True)
    print("nltk:", pkg, "ok")

subprocess.check_call([sys.executable, "-m", "spacy", "download", "en_core_web_sm"])
print("spaCy model ready")

# Pre-download the embedding and QA models so the first upload is not slow.
try:
    from sentence_transformers import SentenceTransformer
    SentenceTransformer("all-MiniLM-L6-v2")
    print("embedding model ready")
except Exception as exc:  # noqa: BLE001
    print("embedding model not downloaded:", exc)

try:
    from transformers import pipeline
    pipeline("question-answering", model="deepset/roberta-base-squad2")
    print("QA model ready")
except Exception as exc:  # noqa: BLE001
    print("QA model not downloaded:", exc)
