"""End-to-end tests. They run in light mode (no model downloads) so they work anywhere."""
import os
import tempfile
import time
from pathlib import Path

os.environ["INTELLIDOC_LIGHT"] = "1"
os.environ["INTELLIDOC_DATA_DIR"] = tempfile.mkdtemp(prefix="intellidoc_test_")

import pytest
from fastapi.testclient import TestClient

from app.main import app

SAMPLE = Path(__file__).resolve().parents[2] / "samples" / "Deep_Learning_Medical_Image_Segmentation.txt"


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def wait_ready(client, doc_id, timeout=60):
    end = time.time() + timeout
    while time.time() < end:
        doc = client.get(f"/api/documents/{doc_id}").json()
        if doc["status"] in ("ready", "failed"):
            return doc
        time.sleep(0.3)
    raise AssertionError("document did not finish processing")


@pytest.fixture(scope="module")
def doc(client):
    with SAMPLE.open("rb") as f:
        r = client.post("/api/documents", files={"file": (SAMPLE.name, f, "text/plain")})
    assert r.status_code == 202
    return wait_ready(client, r.json()["id"])


def test_health(client):
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json()["stages"] == ["Extract", "Preprocess", "Analyse", "Embed", "Index"]


def test_rejects_bad_extension(client):
    r = client.post("/api/documents", files={"file": ("evil.exe", b"abc", "application/octet-stream")})
    assert r.status_code == 400


def test_rejects_empty_file(client):
    r = client.post("/api/documents", files={"file": ("empty.txt", b"", "text/plain")})
    assert r.status_code == 400


def test_document_processed(doc):
    assert doc["status"] == "ready", doc.get("error")
    assert doc["title"] == "Deep Learning Approaches for Medical Image Segmentation"
    assert doc["progress"] == 100


def test_classified_as_research_paper(doc):
    assert doc["category"]["label"] == "Research Paper"
    assert 0 < doc["category"]["confidence"] <= 1


def test_summary_sentences_come_from_document(doc):
    text = " ".join(SAMPLE.read_text(encoding="utf-8").split())
    assert len(doc["summary"]["short"]) > 50
    assert len(doc["summary"]["detailed"]) > len(doc["summary"]["short"])
    for sentence in doc["summary"]["short"].split(". ")[:2]:
        assert sentence.strip(" .")[:40] in text


def test_keywords(doc):
    terms = " ".join(k["term"].lower() for k in doc["keywords"])
    assert len(doc["keywords"]) >= 8
    assert any(w in terms for w in ("dice", "segmentation", "attention", "loss"))
    assert all(0 <= k["score"] <= 1 for k in doc["keywords"])


def test_entities(doc):
    ents = doc["entities"]
    assert set(ents) == {"Person", "Organization", "Location", "Date"}
    assert sum(len(v) for v in ents.values()) > 5
    assert ents["Date"], "expected at least one date"


def test_preprocessing_sample(doc):
    p = doc["preprocessing"]
    assert p["original"]
    assert len(p["no_stopwords"]) < len(p["tokens"])
    assert p["stats"]["sentences"] > 10


def test_semantic_search(client, doc):
    r = client.post("/api/search", json={"query": "loss function for class imbalance", "document_id": doc["id"]})
    assert r.status_code == 200
    results = r.json()["results"]
    assert results
    assert "loss" in results[0]["text"].lower()
    assert results[0]["highlight"]
    assert results[0]["page"] == 1


def test_search_all_documents(client, doc):
    r = client.post("/api/search", json={"query": "Dice coefficient results"})
    assert r.status_code == 200 and r.json()["results"]


def test_question_answering(client, doc):
    r = client.post("/api/ask", json={"question": "Which optimiser was used for training?", "document_id": doc["id"]})
    assert r.status_code == 200
    body = r.json()
    assert body["answer"] and "adam" in body["answer"].lower()
    assert body["sources"]


def test_unanswerable_question(client, doc):
    r = client.post("/api/ask", json={"question": "zzzzqqq xylophone volcano pancake", "document_id": doc["id"]})
    assert r.status_code == 200
    assert r.json()["answer"] is None


def test_list_and_delete(client, doc):
    ids = [d["id"] for d in client.get("/api/documents").json()]
    assert doc["id"] in ids
    assert client.delete(f"/api/documents/{doc['id']}").status_code == 204
    assert client.get(f"/api/documents/{doc['id']}").status_code == 404


def test_docx_and_pdf_extraction(client, tmp_path):
    import docx
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    d = docx.Document()
    d.add_heading("Quarterly Sales Report", 0)
    d.add_paragraph("Revenue grew by twelve percent in the third quarter. The sales team in Chennai closed more deals than any other region. Shareholders were informed on 14 October 2025.")
    d.add_paragraph("The company plans to expand its market share next year by investing in customer support and logistics across southern India.")
    p = tmp_path / "report.docx"
    d.save(p)
    r = client.post("/api/documents", files={"file": ("report.docx", p.read_bytes(), "application/vnd.openxmlformats-officedocument.wordprocessingml.document")})
    out = wait_ready(client, r.json()["id"])
    assert out["status"] == "ready", out.get("error")
    assert out["file_type"] == "DOCX"

    pdf = tmp_path / "paper.pdf"
    c = canvas.Canvas(str(pdf), pagesize=A4)
    for page in range(2):
        c.drawString(72, 780, f"Attention models for segmentation - page {page + 1}")
        y = 750
        for line in SAMPLE.read_text(encoding="utf-8").split(". ")[page * 8: page * 8 + 8]:
            c.drawString(72, y, line[:95])
            y -= 18
        c.showPage()
    c.save()
    r = client.post("/api/documents", files={"file": ("paper.pdf", pdf.read_bytes(), "application/pdf")})
    out = wait_ready(client, r.json()["id"])
    assert out["status"] == "ready", out.get("error")
    assert out["pages"] == 2
    hits = client.post("/api/search", json={"query": "attention models", "document_id": out["id"]}).json()["results"]
    assert hits and hits[0]["page"] in (1, 2)


def test_scanned_pdf_gives_clear_error(client, tmp_path):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    pdf = tmp_path / "blank.pdf"
    c = canvas.Canvas(str(pdf), pagesize=A4)
    c.showPage()
    c.save()
    r = client.post("/api/documents", files={"file": ("blank.pdf", pdf.read_bytes(), "application/pdf")})
    out = wait_ready(client, r.json()["id"])
    assert out["status"] == "failed"
    assert "No text found" in out["error"]
